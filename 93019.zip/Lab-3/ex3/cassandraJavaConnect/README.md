# cassandraJavaConnect
Java Main program as Maven project to connect with cassandra single node instance
