package com.cassandra.javaConnect;

/**
 * @author Vishnu Prabhakar
 * Main program to connect with cassandra instance
 *
 */

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.ResultSet;


public class App {

    public static void main(String[] args) {
        String serverIp = "127.0.0.1";
        String keyspace = "spv";
        Cluster cluster = Cluster.builder().addContactPoints(serverIp).build();
        Session session = cluster.connect(keyspace);
        ResultSet res;
		String query; 
		
		//---- Insert ---//
        System.out.println("_________ Insert _________");
        query = "INSERT INTO video (author, id, title, upload_time, tag) VALUES ('joselmdbsousa@ua.pt', 'id_do_video_do_lucas', 'Video do Lucas', dateof(now()), 'Aula Educativa')";
		System.out.println("> " + query);
		res = session.execute(query);
		System.out.println();
		
		//---- Search ---//
        System.out.println("_________ Search _________");
		query = "select * from video where id = 'id_do_video_do_lucas';";
		System.out.println("> " + query);
		res = session.execute(query);
		for (Row r : res.all()) {
			System.out.println(r);
		}
		System.out.println();

		//---- Search After Update---//
        System.out.println("_________ Search Before Update _________");
		query = "select * from user where email= 'jesusa_hennecke1954@outlook.com';";
		System.out.println("> " + query);
		res = session.execute(query);
		for (Row r : res.all()) {
			System.out.println(r);
		}
		System.out.println();

        //---- Update ---//
		System.out.println("_________ Update _________");
		query = "UPDATE user SET name='Nome modificado!' where email='jesusa_hennecke1954@outlook.com'";
		System.out.println("> " + query);
		session.execute(query);
		System.out.println();

		//---- Search After Update---//
        System.out.println("_________ Search After Update _________");
		query = "select * from user where email= 'jesusa_hennecke1954@outlook.com';";
		System.out.println("> " + query);
		res = session.execute(query);
		for (Row r : res.all()) {
			System.out.println(r);
		}
		System.out.println();

		//------------------Queries-----------------//
		System.out.println("//------------------Queries-----------------//");

		//---- 1) ---//
		System.out.println("_________ 1) _________");
		query = "select * from comment_video where vid_id = '65af5580-3746-11eb-9230-23d9e3bf9773' limit 3;";
		System.out.println("> " + query);
		res = session.execute(query);
		for (Row r : res.all()) {
			System.out.println(r);
		}
		System.out.println();

		//---- 2) ---//
		System.out.println("_________ 2) _________");
		query = "select tag from video where id = '65af5580-3746-11eb-9230-23d9e3bf9773';";
		System.out.println("> " + query);
		res = session.execute(query);
		for (Row r : res.all()) {
			System.out.println(r);
		}
		System.out.println();

		//---- 3) ---//
		System.out.println("_________ 3) _________");
		query = "select * from video_tag where tag = 'Action/Adventure';";
		System.out.println("> " + query);
		res = session.execute(query);
		for (Row r : res.all()) {
			System.out.println(r);
		}
		System.out.println();
		
		//---- 4) ---//
		System.out.println("_________ 4) _________");
		query = "select * from event where vid_id = '65b15150-3746-11eb-9230-23d9e3bf9773' and user = 'marcelina_borghese1959@sapo.pt' limit 5;";
		System.out.println("> " + query);
		res = session.execute(query);
		for (Row r : res.all()) {
			System.out.println(r);
		}
		System.out.println();
		
        session.close();
		System.exit(0);
		
    }
}